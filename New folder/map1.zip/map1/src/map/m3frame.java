/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package map;
import java.sql.*;
import javax.swing.JOptionPane;
import javax.swing.JSlider;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
/**
 *
 * @author lenovo
 */
public class m3frame extends javax.swing.JFrame {

    static  Connection c;
    Statement st;
    PreparedStatement pst;
    ResultSet rs;
static int Id;
    public m3frame(int id) {
initComponents();
Id=id;        
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        slider = new javax.swing.JSlider();
        jSeparator1 = new javax.swing.JSeparator();
        order = new javax.swing.JButton();
        time = new javax.swing.JLabel();
        cost = new javax.swing.JLabel();
        credit = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setAlwaysOnTop(true);
        setBackground(new java.awt.Color(51, 204, 255));
        setFont(new java.awt.Font("Chiller", 3, 24)); // NOI18N

        String t4=null;
        try
        {
            pst=c.prepareStatement("select name from Restaurant where id="+Id+"");
            rs = pst.executeQuery();
            rs.next();
            t4 = rs.getString(1);
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
        jLabel1.setFont(new java.awt.Font("Chiller", 3, 48)); // NOI18N
        jLabel1.setText(t4);

        jLabel2.setFont(new java.awt.Font("Chiller", 3, 24)); // NOI18N
        jLabel2.setText("Address");

        jLabel7.setFont(new java.awt.Font("Chiller", 3, 24)); // NOI18N
        jLabel7.setText("Timings");

        jLabel8.setFont(new java.awt.Font("Chiller", 3, 24)); // NOI18N
        jLabel8.setText("Cost");

        jLabel9.setFont(new java.awt.Font("Chiller", 3, 24)); // NOI18N
        jLabel9.setText("Credit Cards");

        jLabel10.setText("Wanna Rate it!!");

        slider.setMajorTickSpacing(1);
        slider.setMaximum(5);
        slider.setMinimum(1);
        slider.setPaintLabels(true);
        slider.setPaintTicks(true);
        slider.setSnapToTicks(true);
        slider.addChangeListener(new ChangeListener() {
            public void stateChanged(ChangeEvent evt) {
                if (!slider.getValueIsAdjusting()) {
                    {
                        int value = slider.getValue();
                        System.out.println("hereee");
                        Statement st;
                        PreparedStatement pst;
                        ResultSet rs;
                        int val;
                        try

                        {
                            pst =c.prepareStatement("select pop from Restaurant where id="+Id+"");
                            rs = pst.executeQuery();
                            rs.next();
                            val = rs.getInt(1);
                            val+=value;
                            pst=c.prepareStatement("update Restaurant set pop="+value+" where id="+Id+"");
                            pst.executeUpdate();
                        }
                        catch(Exception e)
                        {
                            System.out.println(e);
                        }

                    }
                }
            }
        });

        order.setBackground(new java.awt.Color(102, 204, 255));
        order.setFont(new java.awt.Font("Showcard Gothic", 3, 14)); // NOI18N
        order.setText("Order TakeAway!");
        order.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                orderActionPerformed(evt);
            }
        });

        String t=null;
        try
        {
            pst=c.prepareStatement("select time from Restaurant where id="+Id+"");
            rs = pst.executeQuery();
            rs.next();
            t = rs.getString(1);
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
        time.setFont(new java.awt.Font("Chiller", 3, 18)); // NOI18N
        time.setText(t);

        String t1=null;
        try
        {
            pst=c.prepareStatement("select cost from Restaurant where id="+Id+"");
            rs = pst.executeQuery();
            rs.next();
            t1 = String.valueOf(rs.getInt(1));
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
        cost.setFont(new java.awt.Font("Chiller", 3, 18)); // NOI18N
        cost.setText(t1);

        String t2=null;
        try
        {
            pst=c.prepareStatement("select ccd from Restaurant where id="+Id+"");
            rs = pst.executeQuery();
            rs.next();
            t2 = rs.getString(1);
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
        credit.setFont(new java.awt.Font("Chiller", 3, 18)); // NOI18N
        credit.setText(t2);

        String t5=null;
        try
        {
            pst=c.prepareStatement("select * from Restaurant where id="+Id+"");
            rs = pst.executeQuery();
            rs.next();
            t5=rs.getString(4);
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
        jLabel3.setFont(new java.awt.Font("Chiller", 3, 18)); // NOI18N
        jLabel3.setText(t5);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(34, 34, 34)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 366, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 170, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addGap(10, 10, 10)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel7)
                                    .addComponent(jLabel8)
                                    .addComponent(jLabel9))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(cost)
                                            .addComponent(time)
                                            .addComponent(credit))
                                        .addGap(17, 17, 17))
                                    .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel10)
                                .addGap(104, 104, 104)
                                .addComponent(slider, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(69, 69, 69))))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(159, 159, 159)
                        .addComponent(order))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(144, 144, 144)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 323, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(50, 50, 50)
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(59, 59, 59)
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(62, 62, 62)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(time))
                .addGap(48, 48, 48)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(cost))
                .addGap(30, 30, 30)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(credit))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(order)
                .addGap(18, 18, 18)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(slider, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void orderActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_orderActionPerformed
        m4frame f1 = new m4frame();
        f1.create(Id);
        this.setVisible(false);
        f1.setVisible(true);
        
    }//GEN-LAST:event_orderActionPerformed
public static void main(String args[]) {
     
    //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(m3frame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(m3frame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(m3frame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(m3frame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
  
        System.out.println("MySQL Connect Example.");
  String url = "jdbc:mysql://localhost:3306/";
  String dbName = "map";
  String driver = "com.mysql.jdbc.Driver";
  String userName = "root"; 
  String password = "nive";
  try {
  Class.forName(driver).newInstance();
  c = DriverManager.getConnection(url+dbName,userName,password);
  System.out.println("Connected to the database");
 
  
  } catch (Exception e) {
  e.printStackTrace();
  }
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                }
        });
       
}

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel cost;
    private javax.swing.JLabel credit;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JButton order;
    private static javax.swing.JSlider slider;
    private javax.swing.JLabel time;
    // End of variables declaration//GEN-END:variables
}
